

//alert ("Bienvenido a mi Maquetacion web con ayuda de Bootstrap")

//Vamos a configurar un boton para que sea interactivo con HTML

//Sintaxis basica de onclick


function FunctionConBootstrap() {


    let num = 0;

   num = prompt("Ingresa el codigo para ver Expocicion Artistica virtual o marca 0 para continuar en la web Artes")
    
    if( num == 666 ){

alert("https://expociciondehoy.com")


    }else{

        alert("Bienvenido")
    }



    


    }


/*
Gy = ( "Hola" );
Gy1 = ("MyBellota");

Gy2 = prompt ("Ingresa el numero de veces que la quieres ver..")

for ( let i = 0; i<=666; i ++){

    if (i==Gy2){
    break;

    }

    alert(i+Gy+Gy1+" Hello myRmThKg");

    document.write(i+Gy+Gy1+" Hello myRmThKg");

}

*/